using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Media;


namespace Flappy_Bird
{
    public partial class Form1 : Form
    {
        int Boruh�z� = 11;
        int Yer�ekimi = 10;
        int score = 0;

        public Form1()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space)
            {
                Yer�ekimi = -10;
            }


        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space)
            {

                Yer�ekimi = 10;

            }


        }

        private void timer1_Tick(object sender, EventArgs e)
        {




            Ku�.Top += Yer�ekimi;

            BoruAlt.Left -= Boruh�z�;
            BoruUst.Left -= Boruh�z�;
            label1.Text = "score = " + score.ToString();

            if (BoruAlt.Left < -175)
            {
                BoruAlt.Left = 500;
                score++;
            }

            if (BoruUst.Left < -200)
            {
                BoruUst.Left = 600;
                score++;
            }
            if (Ku�.Bounds.IntersectsWith(BoruUst.Bounds) || Ku�.Bounds.IntersectsWith(BoruAlt.Bounds) ||
                Ku�.Bounds.IntersectsWith(Zemin.Bounds))
            {

                timer1.Enabled = false;


                DialogResult mesaj1 = MessageBox.Show("Oyun Bitti", "�LD�N�Z",
                 MessageBoxButtons.OKCancel, MessageBoxIcon.Stop);
                if (mesaj1 == DialogResult.OK)
                {
                    this.Close();

                }
                else if (mesaj1 == DialogResult.Cancel)
                {
                    this.Close();
                }


            }
            if (score > +10)
            {
                Boruh�z� = 20;
            }
            if (Ku�.Top < -25)
            {
                timer1.Enabled = false;
            }


            void BoruAlt_Clicked(object sender, EventArgs e)
            {

            }
        }
    }
}

