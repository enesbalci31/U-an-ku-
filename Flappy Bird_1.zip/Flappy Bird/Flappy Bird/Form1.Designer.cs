﻿namespace Flappy_Bird
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            Zemin = new PictureBox();
            BoruUst = new PictureBox();
            Kuş = new PictureBox();
            BoruAlt = new PictureBox();
            timer1 = new System.Windows.Forms.Timer(components);
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)Zemin).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BoruUst).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Kuş).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BoruAlt).BeginInit();
            SuspendLayout();
            // 
            // Zemin
            // 
            Zemin.Image = Properties.Resources.ground;
            Zemin.Location = new Point(-12, 468);
            Zemin.Name = "Zemin";
            Zemin.Size = new Size(1038, 77);
            Zemin.SizeMode = PictureBoxSizeMode.StretchImage;
            Zemin.TabIndex = 0;
            Zemin.TabStop = false;
            // 
            // BoruUst
            // 
            BoruUst.Image = Properties.Resources.pipedown;
            BoruUst.Location = new Point(613, -7);
            BoruUst.Name = "BoruUst";
            BoruUst.Size = new Size(105, 160);
            BoruUst.SizeMode = PictureBoxSizeMode.StretchImage;
            BoruUst.TabIndex = 0;
            BoruUst.TabStop = false;
            // 
            // Kuş
            // 
            Kuş.Image = (Image)resources.GetObject("Kuş.Image");
            Kuş.Location = new Point(216, 219);
            Kuş.Name = "Kuş";
            Kuş.Size = new Size(83, 68);
            Kuş.SizeMode = PictureBoxSizeMode.StretchImage;
            Kuş.TabIndex = 0;
            Kuş.TabStop = false;
            // 
            // BoruAlt
            // 
            BoruAlt.Image = Properties.Resources.pipe;
            BoruAlt.Location = new Point(703, 316);
            BoruAlt.Name = "BoruAlt";
            BoruAlt.Size = new Size(100, 156);
            BoruAlt.SizeMode = PictureBoxSizeMode.StretchImage;
            BoruAlt.TabIndex = 0;
            BoruAlt.TabStop = false;
            BoruAlt.Click += BoruAlt_Click;
            // 
            // timer1
            // 
            timer1.Enabled = true;
            timer1.Interval = 20;
            timer1.Tick += timer1_Tick;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(34, 32);
            label1.Name = "label1";
            label1.Size = new Size(13, 20);
            label1.TabIndex = 3;
            label1.Text = " ";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Cyan;
            ClientSize = new Size(1025, 542);
            Controls.Add(label1);
            Controls.Add(BoruAlt);
            Controls.Add(Kuş);
            Controls.Add(BoruUst);
            Controls.Add(Zemin);
            Name = "Form1";
            Text = " ";
            Activated += timer1_Tick;
            Load += Form1_Load;
            KeyDown += Form1_KeyDown;
            KeyUp += Form1_KeyUp;
            Leave += timer1_Tick;
            ((System.ComponentModel.ISupportInitialize)Zemin).EndInit();
            ((System.ComponentModel.ISupportInitialize)BoruUst).EndInit();
            ((System.ComponentModel.ISupportInitialize)Kuş).EndInit();
            ((System.ComponentModel.ISupportInitialize)BoruAlt).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private void BoruAlt_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private PictureBox Zemin;
        private PictureBox BoruUst;
        private PictureBox Kuş;
        private PictureBox BoruAlt;
        private System.Windows.Forms.Timer timer1;
        private Label label1;
    }
}